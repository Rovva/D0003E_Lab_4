void init_io();
